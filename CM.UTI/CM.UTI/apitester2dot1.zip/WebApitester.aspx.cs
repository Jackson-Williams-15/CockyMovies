﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
namespace YourNamespace
{
    public class UsersModel : PageModel
    {
        /*        public string UserName { get; private set; }
                public string UserEmail { get; private set; }
                public void OnGet()
                {
                    var user = GetUserContext();

                    if (user != null)
                    {
                        UserName = user.Name; UserEmail = user.Email;
                    }
                    else
                    {
                        UserName = "User not found."; UserEmail = string.Empty;
                    }
                }
                private UserContext GetUserContext()
                { // Simulate user context; typically fetched from a database or authentication service
                    return new UserContext
                    {
                        Name = "Jane Doe",
                        Email = "jane.doe@example.com"
                    };
                }
            }
            public class UserContext
            {
                public string Name { get; set; }
                public string Email { get; set; }
            }
        */
    }
}
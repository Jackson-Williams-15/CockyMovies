namespace CM.API.Models;
public class Rating
{
    public int Id { get; set; }
    public string Name { get; set; }
}
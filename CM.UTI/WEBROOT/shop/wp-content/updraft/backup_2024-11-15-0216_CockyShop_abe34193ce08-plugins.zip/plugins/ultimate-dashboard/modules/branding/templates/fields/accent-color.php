<?php
/**
 * Accent color field.
 *
 * @package Ultimate_Dashboard_PRO
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

return function () {

	?>

	<input type="text" name="" value="#2271b1" class="udb-color-field udb-branding-color-field udb-instant-preview-trigger" data-default="#2271b1" data-udb-trigger-name="accent-color" />

	<?php

};

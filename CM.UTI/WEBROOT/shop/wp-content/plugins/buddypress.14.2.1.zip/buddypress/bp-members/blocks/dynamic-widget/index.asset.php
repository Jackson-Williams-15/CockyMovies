<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-escape-html', 'wp-i18n'), 'version' => '538e30a01bebc54eb227');

<?php
/**
 * Admin bar logo url field.
 *
 * @package Ultimate_Dashboard
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

return function () {

	?>

	<input type="url" class="regular-text" disabled />

	<?php

};
